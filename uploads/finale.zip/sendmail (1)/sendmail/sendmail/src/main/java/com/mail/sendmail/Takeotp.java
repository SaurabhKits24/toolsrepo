/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mail.sendmail;

import java.util.Scanner;

/**
 *
 * @author ssbha
 */

     
public class Takeotp {
 
    public static void main(String args[]){
         SendEmailreset sendemail = new SendEmailreset();
         String email="ssbhatia2957@gmail.com";
         
    sendemail.base(email);
    sendemail.verifyOtp(email);
    }
     
    public  String takecode(){
Scanner scanner = new Scanner(System.in);
       String   otpget = scanner.nextLine();
        
        return otpget;
       
    }
   
   
    
}
