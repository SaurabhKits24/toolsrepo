package com.mail.sendmail;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Scanner;

public class SendEmailreset {

    private static final String CHARACTERS = "0123456789";
    private static final int CHARACTERS_LENGTH = CHARACTERS.length();
    private static final int MAX_RETRIES = 3; // Maximum number of retries

    // Map to store OTPs for verification (in-memory storage)
    private static Map<String, String> otpStore = new HashMap<>();

    public static String generateOTP(int length) {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(CHARACTERS_LENGTH);
            sb.append(CHARACTERS.charAt(index));
        }
        return sb.toString();
    }

    public static boolean verifyOTP(String email, String otp) {
        return otp.equals(otpStore.get(email));
    }

    public static void main(String[] args) {
        // Change the email here or pass it dynamically
        String email = "recipient@example.com"; // Update with the actual recipient email
        base(email);
        verifyOtp(email);
    }

    public static void base(String email) {
        int otpLength = 6;
        String otp = generateOTP(otpLength);

        // Store the generated OTP (with an email key)
        otpStore.put(email, otp);

        // SMTP server configuration
        String host = "smtp.gmail.com";
        final String username = "ssbhatia2957@gmail.com"; // your email
        final String password = "eqqm frmd zkfw qquz"; // use environment variable for app password

        if (password == null || password.isEmpty()) {
            System.err.println("Email password not set. Please set the EMAIL_PASSWORD environment variable.");
            return;
        }

        // Set up properties for the SMTP server
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true"); // Enable STARTTLS
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "587"); // TLS port

        // Get the Session object with the properties and authenticate
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        // Enable debugging
        session.setDebug(true);

        try {
            // Create a default MimeMessage object
            MimeMessage message = new MimeMessage(session);

            // Set the From, To, Subject, and Content
            message.setFrom(new InternetAddress(username));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(email)); // recipient email
            message.setSubject("Verification Code");
            message.setText("This is your OTP: " + otp);

            // Send message
            Transport.send(message);
            System.out.println("Email sent successfully.");
        } catch (MessagingException e) {
            System.err.println("Failed to send email: " + e.getMessage());
            e.printStackTrace(); // Print detailed stack trace for debugging
        }
    }

    static void verifyOtp(String email) {
        Scanner scanner = new Scanner(System.in);
         PartialReset otpget = new PartialReset();
       
        boolean isVerified = false;
        
        int attempts = 0;

        try {
            while (attempts < MAX_RETRIES && !isVerified) {
                attempts++;
                System.out.print("Enter the OTP: ");
                 String userInputOtp = otpget.takecode();

                if (verifyOTP(email, userInputOtp)) {
                    System.out.println("OTP verified successfully.");
                    isVerified = true;
                } else {
                    if (attempts < MAX_RETRIES) {
                        System.out.println("Invalid OTP. You have " + (MAX_RETRIES - attempts) + " attempts left.");
                    } else {
                        System.out.println("Invalid OTP. No attempts left.");
                    }
                }
            }

            if (!isVerified) {
                System.out.println("Failed to verify OTP. Please request a new OTP.");
            }
        } finally {
            // Clear OTP from store after verification or when attempts are exhausted
            scanner.close();
            otpStore.remove(email);
           
        }
    }
}
