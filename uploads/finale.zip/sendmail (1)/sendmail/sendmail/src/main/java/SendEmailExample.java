import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class SendEmailExample {

    public static void main(String[] args) {
        // Set SMTP server properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");  // Replace with your SMTP server
        properties.put("mail.smtp.port", "587");               // For example, 587 for TLS, 465 for SSL
        properties.put("mail.smtp.auth", "true");              // Enable authentication
        properties.put("mail.smtp.starttls.enable", "true");   // Enable STARTTLS

        // Create a Session object with the SMTP server properties
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("ssbhatia2957@gmail.com", "eqqmfrmdzkfwqquz"); // Replace with your email and password
            }
        });

        try {
            // Create a default MimeMessage object
            Message message = new MimeMessage(session);

            // Set From: header field
            message.setFrom(new InternetAddress("ssbhatia2957@gmail.com")); // Replace with your email

            // Set To: header field
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("ssbhatia2957@gmail.com")); // Replace with recipient's email

            // Set Subject: header field
            message.setSubject("Test Subject");

            // Set the actual message
            message.setText("This is a test email sent from JavaMail API!");

            // Send the message
            Transport.send(message);

            System.out.println("Email sent successfully!");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
